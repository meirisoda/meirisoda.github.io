---
layout: default
nav_exclude: true
---
# Tests for exclusion untitled and excluded

This page does not have a `title`, and it is explicitly excluded from the navigation

```yaml
nav_exclude: true
```
