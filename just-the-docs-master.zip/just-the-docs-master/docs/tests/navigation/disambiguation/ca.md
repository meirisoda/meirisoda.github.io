---
layout: default
title: Tests for disambiguation C
parent: Tests for disambiguation A
has_children: true
---

# C

A child of page A, and parent of page D

```yaml
title: Tests for disambiguation C
parent: Tests for disambiguation A
has_children: true
```
