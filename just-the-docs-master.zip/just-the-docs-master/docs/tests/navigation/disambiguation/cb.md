---
layout: default
title: Tests for disambiguation C
parent: Tests for disambiguation B
has_children: true
---

# C

A child of page B, and parent of page D

```yaml
title: Tests for disambiguation C
parent: Tests for disambiguation B
has_children: true
```
