---
layout: default
title: Tests for disambiguation B
has_children: true
---

# B

A top-level page

```yaml
title: Tests for disambiguation B
has_children: true
```
