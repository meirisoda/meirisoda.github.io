---
layout: default
title: Mixture
parent: Tests for order
nav_order: 5
has_children: true
---

# Mixed Order

It seems unlikely that different types of `nav_order` values are needed for the children of the same parent.
