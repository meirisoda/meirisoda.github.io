---
layout: default
title: A
parent: Mixture
grand_parent: Tests for order
---

# A

```yaml
title: A
parent: Mixture
grand_parent: Tests for order
```
